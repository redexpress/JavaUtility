package org.ff4j.sample;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;

import org.ff4j.FF4j;
import org.ff4j.core.Feature;
import org.ff4j.property.PropertyString;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;


@Controller
@RequestMapping("/")
public class HomeController {

    @GetMapping("/hello")
    @ResponseBody
    public String hello() {
        return "hello";
    }
    

    private static final Logger LOGGER = LoggerFactory.getLogger(HomeController.class);
    private static final String FEATURE_SHOW_WEBCONSOLE = "showWebConsoleURL";
	private static final String FEATURE_SHOW_REST_API   = "showRestApiURL";
	private static final String FEATURE_SHOW_USERNAME   = "showUserName";
	private static final String PROPERTY_USERNAME       = "username";
	
    private static final String FEATURE_AWESOME = "AwesomeFeature";
    private static final String FEATURE1      = "first";
    private static final String PROPERTY1     = "a";
    
    @Autowired
    public FF4j ff4j;
	
	@PostConstruct
    public void populateDummyFeatureForMySample() {
        if (!ff4j.exist(FEATURE_SHOW_WEBCONSOLE)) {
            ff4j.createFeature(new Feature(FEATURE_SHOW_WEBCONSOLE, true));
        }
        if (!ff4j.exist(FEATURE_SHOW_REST_API)) {
            ff4j.createFeature(new Feature(FEATURE_SHOW_REST_API, true));
        }
        if (!ff4j.exist(FEATURE_SHOW_USERNAME)) {
            ff4j.createFeature(new Feature(FEATURE_SHOW_USERNAME, true));
        }
        if (!ff4j.getPropertiesStore().existProperty(PROPERTY_USERNAME)) {
            ff4j.createProperty(new PropertyString(PROPERTY_USERNAME, "cedrick"));
        }
        LOGGER.info(" + Features and properties have been created for the sample.");
    }
	
    
    @GetMapping("/")
    public String home(HttpServletRequest req, Model model) {

        // if not exist, create and evaluate
        model.addAttribute("featureAwesomeFlag", ff4j.check(FEATURE_AWESOME));

        // Have a behaviour based on the state of a feature
        if (ff4j.check(FEATURE1)) {
            LOGGER.info(FEATURE1 + " should be activated");
        }

        // You could make available Feature in the UI as an Object
        if (ff4j.getFeatureStore().exist(FEATURE_AWESOME)) {
            model.addAttribute("ff4j_features_Awesomefeature", ff4j.getFeature(FEATURE_AWESOME));
        }

        // You could make available Feature in the UI as an Object
        if (ff4j.getPropertiesStore().existProperty(PROPERTY1)) {
            model.addAttribute("ff4j_properties_a", ff4j.getProperty(PROPERTY1));
        }

        return "index";
    }
}
