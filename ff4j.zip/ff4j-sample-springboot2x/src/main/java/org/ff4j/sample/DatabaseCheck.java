package org.ff4j.sample;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

@Component
public class DatabaseCheck {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @PostConstruct
    public void checkTables() {
        try {
            // 查询 FF4J_FEATURES 表
            Integer count = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM FF4J_FEATURES", Integer.class);
            System.out.println("FF4J_FEATURES 表存在，记录数：" + count);
        } catch (Exception e) {
            System.out.println("FF4J_FEATURES 表不存在：" + e.getMessage());
        }
    }
}
