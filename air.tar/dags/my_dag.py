from airflow import DAG
from airflow.operators.bash_operator import BashOperator
from airflow.operators.python_operator import PythonOperator
from airflow.hooks.base_hook import BaseHook
from datetime import datetime


def read_file_content(**kwargs):
    conn = BaseHook.get_connection(kwargs['conn_id'])
    file_path = conn.extra_dejson.get('file_path') 
    print('filepath is ', file_path)


with DAG(
    'my_dag', 
    start_date=datetime(2023, 1, 1),
    schedule_interval=None,
    catchup=False,
    tags=['example', 'my']
) as dag:

    show_date = BashOperator(
        task_id='show_date1',
        bash_command='date'
    )

    read_file = PythonOperator(
        task_id='read_file1',
        python_callable=read_file_content,
        op_kwargs={'conn_id': 'my_fs'},
    )

    show_date >> read_file