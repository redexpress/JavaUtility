from airflow import DAG
from airflow.operators.bash_operator import BashOperator
from airflow.operators.python_operator import PythonOperator
from airflow.hooks.base_hook import BaseHook
from datetime import datetime
from airflow.exceptions import AirflowClusterPolicyViolation


def read_file_content(**kwargs):
    conn = BaseHook.get_connection(kwargs['conn_id'])
    print('conn is:', str(conn))
    name = str(conn)
    if name[:2] != 'my':
        raise AirflowClusterPolicyViolation('conn prefix')
    file_path = conn.extra_dejson.get('file_path')
    filepath = conn.extra_dejson.get('filepath') 
    print('file_path is:', file_path)
    print('filepath is:', filepath)
    if file_path is None:
        raise AirflowClusterPolicyViolation('file is none')


with DAG(
    'my_flow', 
    start_date=datetime(2023, 1, 1),
    schedule_interval=None,
    catchup=False,
    tags=['example', 'my']
) as dag:

    show_date = BashOperator(
        task_id='show_date',
        bash_command='date'
    )

    read_file = PythonOperator(
        task_id='read_file',
        python_callable=read_file_content,
        op_kwargs={'conn_id': 'fs_conn'},
    )

    show_date >> read_file