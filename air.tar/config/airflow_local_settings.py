# AIRFLOW_HOME/airflow_local_settings.py
from airflow.exceptions import AirflowClusterPolicyViolation
from airflow.settings import dag_policy
from airflow.settings import task_policy


CHECKED_CONNECTION_TYPES = ['fs', 'github', 'generic']

def custom_dag_policy(dag):
    # required_tag = 'example2'
    # if not dag.tags or required_tag not in dag.tags:
    #     raise ValueError(f"DAG '{dag.dag_id}' must have the '{required_tag}' tag.")
    # print(dag.tags)
    return

def get_prefix(name):
    return name[:2]

def custom_task_policy(task):
    dag_id_prefix = get_prefix(task.dag_id)
    task_connections = getattr(task, 'conn_id', None)
    print('task_connections is:', task_connections)
    print('dag_id_prefix is:', dag_id_prefix)
    if task_connections:
        for conn_id in task_connections if isinstance(task_connections, list) else [task_connections]:
            connection_prefix = get_prefix(conn_id)
            connection = task.get_connection(conn_id) 
            conn_type = connection.conn_type 
            print('conn_type is:', conn_type)
            print('connection_prefix:', connection_prefix)
            if conn_type in CHECKED_CONNECTION_TYPES and connection_prefix != dag_id_prefix:
                raise AirflowClusterPolicyViolation(f"ERR: '{connection_prefix}' != '{dag_id_prefix}' ")
    else:
        if task.dag_id[:3] == 'my_' and task.task_id[:4] == 'read':
            raise AirflowClusterPolicyViolation(f"ERR: connect prefix is not match")


dag_policy = custom_dag_policy
task_policy = custom_task_policy

